import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { MedicationCard } from './components/MedicationCard';
import { AddMedicationForm } from './components/AddMedicationForm';
import { AuthForm } from './components/AuthForm';
import { Navigation } from './components/Navigation';
import { Medication, MedicationFormData, User, Tab } from './types';

function App() {
  const [medications, setMedications] = useState<Medication[]>(() => {
    const saved = localStorage.getItem('medications');
    return saved ? JSON.parse(saved) : [];
  });
  const [showAddForm, setShowAddForm] = useState(false);
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('user');
    return saved ? JSON.parse(saved) : null;
  });
  const [authType, setAuthType] = useState<'login' | 'signup'>('login');
  const [activeTab, setActiveTab] = useState<Tab>('home');

  useEffect(() => {
    localStorage.setItem('medications', JSON.stringify(medications));
  }, [medications]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    }
  }, [user]);

  const handleAddMedication = (data: MedicationFormData) => {
    const newMedication: Medication = {
      id: crypto.randomUUID(),
      ...data,
      history: [],
    };
    setMedications([...medications, newMedication]);
  };

  const handleMarkTaken = (id: string, time: string) => {
    const today = new Date().toISOString().split('T')[0];
    
    setMedications(medications.map(med => {
      if (med.id === id) {
        return {
          ...med,
          history: [
            ...med.history,
            { date: today, time, taken: true }
          ]
        };
      }
      return med;
    }));
  };

  const handleAuth = (userData: User) => {
    setUser(userData);
  };

  if (!user) {
    return (
      <div>
        <AuthForm type={authType} onSubmit={handleAuth} />
        <p className="text-center mt-4 text-gray-600">
          {authType === 'login' ? (
            <>
              Don't have an account?{' '}
              <button
                onClick={() => setAuthType('signup')}
                className="text-blue-600 hover:underline"
              >
                Sign up
              </button>
            </>
          ) : (
            <>
              Already have an account?{' '}
              <button
                onClick={() => setAuthType('login')}
                className="text-blue-600 hover:underline"
              >
                Log in
              </button>
            </>
          )}
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">
            Med-Tracker
          </h1>
        </div>

        {medications.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">
              No medications added yet. Click the plus button to add one.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {medications.map((medication) => (
              <MedicationCard
                key={medication.id}
                medication={medication}
                onMarkTaken={handleMarkTaken}
              />
            ))}
          </div>
        )}

        {showAddForm && (
          <AddMedicationForm
            onAdd={handleAddMedication}
            onClose={() => setShowAddForm(false)}
          />
        )}

        <button
          onClick={() => setShowAddForm(true)}
          className="fixed bottom-6 right-6 w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}

export default App;