export interface Medication {
  id: string;
  name: string;
  timings: string[];
  frequency: number;
  history: {
    date: string;
    time: string;
    taken: boolean;
  }[];
}

export interface MedicationFormData {
  name: string;
  frequency: number;
  timings: string[];
}

export interface User {
  firstName: string;
  lastName: string;
  gender: 'male' | 'female' | 'other';
  dateOfBirth: string;
  age: number;
  email: string;
  password: string;
}

export type Tab = 'home' | 'update' | 'medications' | 'manage' | 'profile';