import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { MedicationFormData } from '../types';

interface Props {
  onAdd: (medication: MedicationFormData) => void;
  onClose: () => void;
}

export function AddMedicationForm({ onAdd, onClose }: Props) {
  const [formData, setFormData] = useState<MedicationFormData>({
    name: '',
    frequency: 1,
    timings: ['08:00'],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
    onClose();
  };

  const handleTimingChange = (index: number, value: string) => {
    const newTimings = [...formData.timings];
    newTimings[index] = value;
    setFormData({ ...formData, timings: newTimings });
  };

  const addTiming = () => {
    if (formData.timings.length < formData.frequency) {
      setFormData({
        ...formData,
        timings: [...formData.timings, '12:00'],
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
      <div className="bg-white rounded-xl p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Add New Medication</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Medication Name
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Times per Day
            </label>
            <select
              value={formData.frequency}
              onChange={(e) => setFormData({ ...formData, frequency: Number(e.target.value) })}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {[1, 2, 3, 4].map((n) => (
                <option key={n} value={n}>
                  {n} time{n > 1 ? 's' : ''} per day
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-3">
            <label className="block text-sm font-medium text-gray-700">
              Timings
            </label>
            {formData.timings.map((timing, index) => (
              <input
                key={index}
                type="time"
                required
                value={timing}
                onChange={(e) => handleTimingChange(index, e.target.value)}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              />
            ))}
            {formData.timings.length < formData.frequency && (
              <button
                type="button"
                onClick={addTiming}
                className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
              >
                <Plus className="w-4 h-4" />
                Add timing
              </button>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Add Medication
          </button>
        </form>
      </div>
    </div>
  );
}