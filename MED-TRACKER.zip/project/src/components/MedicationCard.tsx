import React from 'react';
import { Clock, Check, Pill } from 'lucide-react';
import { Medication } from '../types';

interface Props {
  medication: Medication;
  onMarkTaken: (id: string, time: string) => void;
}

export function MedicationCard({ medication, onMarkTaken }: Props) {
  const today = new Date().toISOString().split('T')[0];
  const todayHistory = medication.history.filter(h => h.date === today);

  return (
    <div className="relative group perspective-1000">
      <div className="bg-white rounded-xl p-6 shadow-lg transform transition-transform duration-500 group-hover:rotate-y-10 group-hover:scale-105">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Pill className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800">{medication.name}</h3>
          </div>
          <span className="text-sm text-gray-500">
            {medication.frequency}x daily
          </span>
        </div>

        <div className="space-y-3">
          {medication.timings.map((time, index) => {
            const taken = todayHistory.some(h => h.time === time && h.taken);
            
            return (
              <div key={time} 
                className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gray-600" />
                  <span className="text-gray-700">{time}</span>
                </div>
                
                {taken ? (
                  <span className="flex items-center gap-1 text-green-600">
                    <Check className="w-4 h-4" />
                    Taken
                  </span>
                ) : (
                  <button
                    onClick={() => onMarkTaken(medication.id, time)}
                    className="px-3 py-1 text-sm bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
                  >
                    Mark as taken
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}