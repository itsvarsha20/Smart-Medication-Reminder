import React from 'react';
import { Home, RefreshCw, Pill, Settings, User } from 'lucide-react';

interface Props {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function Navigation({ activeTab, onTabChange }: Props) {
  const tabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'update', icon: RefreshCw, label: 'Update' },
    { id: 'medications', icon: Pill, label: 'Medications' },
    { id: 'manage', icon: Settings, label: 'Manage' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex justify-between">
          {tabs.map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => onTabChange(id)}
              className={`flex flex-col items-center py-4 px-6 transition-colors ${
                activeTab === id
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              <Icon className="w-5 h-5 mb-1" />
              <span className="text-sm">{label}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}